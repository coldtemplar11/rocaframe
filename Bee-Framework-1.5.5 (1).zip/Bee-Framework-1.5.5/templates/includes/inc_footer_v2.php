<!-- footer v2 -->
<footer class="my-5 pt-5 text-muted text-center text-small">
  <p class="mb-1"><?php echo get_sitename().' '.date('Y').' &copy; Todos los derechos reservados.'; ?></p>
</footer>

<?php require_once INCLUDES.'inc_scripts.php'; ?>

</body>
</html>